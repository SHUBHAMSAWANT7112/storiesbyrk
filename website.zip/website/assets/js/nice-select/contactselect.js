NiceSelect.bind(document.getElementById("numberofguests"), {
  searchable: false,
  placeholder: 'Number of guests'
});

NiceSelect.bind(document.getElementById("mealpreferences"), {
  searchable: false,
  placeholder: 'Meal preferences'
});