export default function minTranslate() {
  return -this.snapGrid[0];
}
